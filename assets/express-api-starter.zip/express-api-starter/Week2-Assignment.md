(Original assignment file placeholder)
Please check your instructor-supplied Week2-Assignment.md for grading criteria.
